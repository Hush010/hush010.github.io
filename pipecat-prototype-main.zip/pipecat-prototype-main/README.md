# Pipecat Prototype

This is a minimal demo of a Pipecat pipeline showing a live speaking agent over WebRTC.

## Setup

1. **Clone the repo**
   ```bash
   git clone https://github.com/YOUR_USERNAME/pipecat-prototype.git
   cd pipecat-prototype
